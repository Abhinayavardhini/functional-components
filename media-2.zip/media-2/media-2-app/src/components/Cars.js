import React from 'react'

function Cars(props) {
  return (
    <div>
      <div className="mainDiv">
      <div className="picDiv">
      <img src={props.logo}></img>
      <h6>Logo</h6>
      </div>
      <div className="picDiv">
      <img src={props.pic}></img>
      <h6>Latest Upcoming Model</h6>
      </div>
      <div className="detailsDiv">
      <h1><u>Details</u></h1>
      <h3>NAME: {props.Name}</h3>
      <h5>Price: {props.price} Lakh <small>Estimated price</small></h5>
      <h5> Estimated launch: {props.date} <small>(Tentative)</small></h5>
      </div>
    </div>
      
    </div>
  )
}

export default Cars
