import logo from './logo.svg';
import './App.css';
import Cars from './components/Cars';

function App() {
  return (
    <div>
      <div><h1>With out using functional components</h1></div>
    <div className="mainDiv">
      <div className="picDiv">
      <img src="./images/tatalogo.png"></img>
      <h6>Logo</h6>
      </div>
      <div className="picDiv">
      <img src="./images/tataharrierev.webp"></img>
      <h6>Latest Upcoming Model</h6>
      </div>
      <div className="detailsDiv">
      <h1><u>Details</u></h1>
      <h3>TATA HARRIER EV</h3>
      <h5>24.00-28.00 Lakh <small>Estimated price</small></h5>
      <h5> Estimated launch: sep 2024 <small>(Tentative)</small></h5>
      </div>
    </div>
    <div className="mainDiv">
      <div className="picDiv">
      <img src="./images/mahindralogo.jpeg"></img>
      <h6>Logo</h6>
      </div>
      <div className="picDiv">
      <img src="./images/mahindra xuv-300-ev.avif"></img>
      <h6>Latest Upcoming Model</h6>
      </div>
      <div className="detailsDiv">
      <h1><u>Details</u></h1>
      <h3>MAHINDRA XUV-300 EV</h3>
      <h5>15.00 LAkh <small>Estimated Starting price</small></h5>
      <h5> Estimated launch: June 2024 </h5>
      </div>
    </div>
    <div className="mainDiv">
      <div className="picDiv">
      <img src="./images/maruthilogo.jpeg"></img>
      <h6>Logo</h6>
      </div>
      <div className="picDiv">
      <img src="./images/s-cross facelift.avif"></img>
      <h6>Latest Upcoming Model</h6>
      </div>
      <div className="detailsDiv">
      <h1><u>Details</u></h1>
      <h3>MARUTHI S-CROSS FACELIFT</h3>
      <h5>10.00-15.00 Lakh <small>Estimated price</small></h5>
      <h5> Expected launch Date: June 2024 </h5>
      </div>
    </div>
    <div className="mainDiv">
      <div className="picDiv">
      <img src="./images/hyundailogo.jpeg"></img>
      <h6>Logo</h6>
      </div>
      <div className="picDiv">
      <img src="./images/palisade.webp"></img>
      <h6>Latest Upcoming Model</h6>
      </div>
      <div className="detailsDiv">
      <h1><u>Details</u></h1>
      <h3>Hyundai Palisade</h3>
      <h5>40.00 Lakh <small>Estimated price</small></h5>
      <h5> Expected launch Date: August 2024 </h5>
      </div>
    </div>
    <hr></hr>
    <div><h1>With using functional components</h1></div>
    <Cars logo="./images/tatalogo.png" pic="./images/tataharrierev.webp" Name="TATA HARRIER EV" price="24.00-28.00" date="sep 2024"></Cars>
    <Cars logo="./images/mahindralogo.jpeg" pic="./images/mahindra xuv-300-ev.avif" Name="MAHINDRA XUV-300-EV" price="15.00" date="June 2024"></Cars>
    <Cars logo="./images/maruthilogo.jpeg" pic="./images/s-cross facelift.avif" Name="MARUTHI S-CROSS FACELIFT" price="10.00-15.00" date="June 2024"></Cars>
    <Cars logo="./images/hyundailogo.jpeg" pic="./images/palisade.webp" Name="HYUNDAI PALISADE" price="40.00" date="August 2024"></Cars>
    </div>
  );
}

export default App;
